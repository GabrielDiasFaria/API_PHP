# api-rest-php
Exemplo de CRUD utilizando arquitetura RESTful, feito com php.


  Uma coisa que não vi durante minha graduação e achava que se tratava de um bixo de 7 cabeças é tudo que envolve arquitetura RESTful. Até no trabalho nunca me foi solicitado trabalhar com API's, nome que só de ouvir falar já me causava certo receio.
 
  Segundo a wikipedia, 'O termo REST se referia, originalmente, a um conjunto de princípios de arquitetura, na atualidade se usa no sentido mais amplo para descrever qualquer interface web simples que utiliza XML e HTTP (ou YAML, JSON, ou texto puro), sem as abstrações adicionais dos protocolos baseados em padrões de trocas de mensagem como o protocolo de serviços Web SOAP.' (http://pt.wikipedia.org/wiki/REST)
 
  Infelizmente sou daqueles caras que só aprende na base da pancada, e com relação a trabalhar com webservices não foi diferente. Houve um belo dia em que me chamaram para uma entrevista de emprego e me foi solicitado que eu criasse um CRUD de uma aplicação aleatória onde a mesma teria que ser feita no formato de API, utilizando arquitetura RESTful, enviando e consumindo dados no formato JSON.
 
  Por sorte o cara que me entrevistou permitiu que eu fizesse a aplicação em casa (fui sincero com ele, disse que precisaria pesquisar a respeito, e que na hora eu não iria conseguir fazer). Em um ou dois dias eu aprendi  e consegui (com a ajuda de um amigo meu) finalizar o projeto que foi pedido. Claro que é algo simples, mas me ajudou e muito a clarear minha visão a respeito do assunto.
  
  Espero que fique claro para quem ler o código, além de agradecer imensamente dicas e melhorias no código :D
